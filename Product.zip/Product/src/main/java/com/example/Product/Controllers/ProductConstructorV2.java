package com.example.Product.Controllers;

import com.example.Product.Services.impl.GroceryImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class ProductConstructorV2 {
    @Autowired
    GroceryImpl GroceryImpl;

    @Autowired
    public void checkPrototype(GroceryImpl GroceryImpl) {
        System.out.println("checkPrototype : Called");
    }
}
