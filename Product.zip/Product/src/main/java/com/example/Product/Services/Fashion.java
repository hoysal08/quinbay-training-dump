package com.example.Product.Services;

public interface Fashion {
    public String placeOrder();
}
