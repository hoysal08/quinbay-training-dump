package com.example.Product.Controllers;

import com.example.Product.Services.impl.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class ProductController {

    @Autowired
    GroceryImpl GroceryImpl;

    @Autowired
    Jeans Jeans;

    @Autowired
    Laptop Laptop;

    @Autowired
    Mobile Mobile;

    @Autowired
    Shirt Shirt;


}
