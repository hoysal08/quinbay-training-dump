package com.example.Product.Services.impl;

import com.example.Product.Services.Fashion;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

@Service
public class Shirt implements Fashion {

    @Override
    public String placeOrder() {
        System.out.println("Shirt : placeOrder Called ");
        return "Order Placed : Shirt";
    }

    @PostConstruct
    public void postConstructor() {
        System.out.println("Shirt Constructed");
    }
}
