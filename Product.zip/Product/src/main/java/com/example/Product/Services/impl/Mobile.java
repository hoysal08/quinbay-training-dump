package com.example.Product.Services.impl;

import com.example.Product.Services.Electronics;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

@Service
public class Mobile implements Electronics {


    @Override
    public String placeOrder() {
        System.out.println("Mobile : placeOrder Called ");
        return "Order Placed : Mobile";
    }

    @PostConstruct
    public void postConstructor() {
        System.out.println("Mobile Constructed");
    }
}
