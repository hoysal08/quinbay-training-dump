package com.example.Product.Services.impl;


import com.example.Product.Services.Electronics;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

@Service
public class Laptop implements Electronics {


    @Override
    public String placeOrder() {
        System.out.println("Laptop : placeOrder Called ");
        return "Order Placed : Laptop";
    }

    @PostConstruct
    public void postConstructor() {
        System.out.println("Laptop Constructed");
    }
}
