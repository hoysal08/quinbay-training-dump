package com.example.Product.Services;

public interface Electronics {
    public String placeOrder();
}
