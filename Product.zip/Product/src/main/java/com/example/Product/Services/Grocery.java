package com.example.Product.Services;

public interface Grocery {
    public String placeOrder();
}
