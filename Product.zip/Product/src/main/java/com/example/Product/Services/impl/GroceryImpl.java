package com.example.Product.Services.impl;

import com.example.Product.Services.Grocery;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

@Service
@Scope(value = "prototype")
public class GroceryImpl implements Grocery {

    @Override
    public String placeOrder() {
        System.out.println("GroceryImpl : placeOrder Called ");
        return "Order Placed : Grocery";
    }

    @PostConstruct
    public void postConstructor() {
        System.out.println("GroceryImpl Constructed");
    }
}
