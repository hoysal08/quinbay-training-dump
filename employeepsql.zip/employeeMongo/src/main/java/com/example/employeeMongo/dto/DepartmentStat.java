package com.example.employeeMongo.dto;

import lombok.Data;

@Data
public class DepartmentStat {
    private String departmentName;
    private int departmentCount;
}
