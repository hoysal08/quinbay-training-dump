package com.example.employeeMongo.dto;

import lombok.Data;

@Data
public class CompanyDto {
    private String companyId;

    private String companyName;
}
