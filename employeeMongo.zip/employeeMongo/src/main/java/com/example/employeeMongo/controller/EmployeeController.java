package com.example.employeeMongo.controller;


import com.example.employeeMongo.dto.EmployeeDto;
import com.example.employeeMongo.dto.EmployeeResponseDTO;
import com.example.employeeMongo.entity.BankAccount;
import com.example.employeeMongo.entity.Company;
import com.example.employeeMongo.entity.Employee;
import com.example.employeeMongo.service.EmployeeService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;


    @PostMapping
    public ResponseEntity<Boolean> addEmployee(@RequestBody EmployeeDto employeeDto) {
        Boolean inserted = employeeService.addEmployee(employeeDto);
        if (inserted) {
            return new ResponseEntity<>(Boolean.TRUE, HttpStatus.CREATED);
        }
        return new ResponseEntity<>(Boolean.FALSE, HttpStatus.BAD_REQUEST);

    }

    @GetMapping
    public List<EmployeeResponseDTO> getAllEmployees() {

        Iterable<Employee> data = employeeService.getAll();
        List<EmployeeResponseDTO> responseDtos = new ArrayList<>();
        for (Employee employee : data) {
            Company company = employee.getCompany();
            BankAccount bankAccount = employee.getBankAccount();
            EmployeeResponseDTO employeeDTO = new EmployeeResponseDTO();
            BeanUtils.copyProperties(employee, employeeDTO);
            employeeDTO.setDateOfBirth(employee.getDob() != null ? employee.getDob().getTime() : 0);
            employeeDTO.setDateofJoining(employee.getDoj() != null ? employee.getDoj().getTime() : 0);
            company.setEmployees(null);
            bankAccount.setEmployee(null);
            employeeDTO.setCompanyDto(company);
            employeeDTO.setBankAccountDto(bankAccount);
            responseDtos.add(employeeDTO);
        }
        return responseDtos;
    }

    @DeleteMapping
    public Boolean deleteAll() {
        employeeService.deleteAll();
        return Boolean.TRUE;
    }

    @GetMapping("/id/{employeeId}")
    public EmployeeResponseDTO employeeGetById(@PathVariable String employeeId) {
        Employee employee = employeeService.getEmployeeById(employeeId);
        EmployeeResponseDTO employeeDTO = new EmployeeResponseDTO();
        BeanUtils.copyProperties(employee, employeeDTO);
        employeeDTO.setDateOfBirth(employee.getDob().getTime());
        employeeDTO.setDateofJoining(employee.getDoj().getTime());
        return employeeDTO;
    }

    @PutMapping()
    public Employee editEmployee(@RequestBody EmployeeDto employeeDto, @RequestParam("employeeId") String employeeId) {
        Employee employee = employeeService.editEmployee(employeeDto, employeeId);
        return employee;
    }

    @DeleteMapping("/id/{employeeId}")
    public Boolean deleteEmployeeById(@PathVariable String employeeId) {
        Boolean deleted = employeeService.deleteById(employeeId);
        return deleted;
    }

    @GetMapping("/exists/{employeeId}")
    public Boolean employeeExists(@PathVariable String employeeId) {
        return employeeService.employeeExists(employeeId);
    }

    @PutMapping("/new_additonal_dets")
    public Employee addBankAndCompany(Employee employee, String companyId, String bankAccount) {
        return employeeService.save(employee, companyId, bankAccount);
    }


    @GetMapping("/all")
    public List<EmployeeDto> getAllEmployeeJPA() {
        List<Employee> result = employeeService.getAllEmployeeJPA();
        List<EmployeeDto> returnEmployee = new ArrayList<>();

        for( Employee emp:result){
            EmployeeDto empDTO = new EmployeeDto();
            BeanUtils.copyProperties(emp,empDTO);
            returnEmployee.add(empDTO);
        }
        return returnEmployee;


    }


}


