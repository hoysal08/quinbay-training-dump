package com.example.employeeMongo.dto;

public class BankAccountDto {
}
