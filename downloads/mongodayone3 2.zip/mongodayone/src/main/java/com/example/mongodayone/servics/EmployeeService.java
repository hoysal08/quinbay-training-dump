package com.example.mongodayone.servics;

import com.example.mongodayone.dto.CountByDepartment;
import com.example.mongodayone.dto.EmployeeDto;
import com.example.mongodayone.entity.Employee;

import java.util.List;

public interface EmployeeService {
    boolean addEmployee(EmployeeDto employeeDto);

    List<Employee> getAll();

    boolean clearAll();

    Employee get(String id);

    boolean deleteById(String id);

    boolean isEmployeeExist(String id);

    List<Employee> firstName(String firstName);

    List<CountByDepartment> countByDept();

//    EmployeeDto update(EmployeeDto employee,String employeeId);
}
