package com.example.mongodayone.dto;

import lombok.Data;

@Data
public class EmployeeResponseDto {
    private String employeeId;
    private String firstName;
    private String lastName;
    private long dob;
    private long doj;
    private String dept;
    private long age;
}
