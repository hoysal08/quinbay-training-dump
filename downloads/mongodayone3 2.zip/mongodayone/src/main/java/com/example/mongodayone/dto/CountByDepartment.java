package com.example.mongodayone.dto;

import lombok.Data;

@Data
public class CountByDepartment {
    private int department_count;
    private String department;
}
