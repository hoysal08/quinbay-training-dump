package com.example.mongodayone.servics.impl;

import com.example.mongodayone.dto.CountByDepartment;
import com.example.mongodayone.dto.EmployeeDto;
import com.example.mongodayone.entity.Employee;
import com.example.mongodayone.repository.EmployeeCustomRepository;
import com.example.mongodayone.repository.EmployeeRepository;
import com.example.mongodayone.servics.EmployeeService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private EmployeeCustomRepository employeeCustomRepository;

    @Override
    public boolean addEmployee(EmployeeDto employeeDto) {

        Employee employee = new Employee();
        BeanUtils.copyProperties(employeeDto,employee);
        employee.setDob(new Date(employeeDto.getDob()));
        employee.setDoj(new Date(employeeDto.getDoj()));
        employee.setEmployeeId(UUID.randomUUID().toString());
        Employee savedEmployee = employeeRepository.save(employee);
        return Objects.nonNull(savedEmployee);
    }

    @Override
    public List<Employee> getAll() {
        List<Employee> data = employeeRepository.findAll();
        return data;
    }

    @Override
    public boolean clearAll() {
        employeeRepository.deleteAll();
        return true;
    }

    @Override
    public Employee get(String employeeId) {

        Optional<Employee> employeeOptional= employeeRepository.findById(employeeId);
        return employeeOptional.isPresent() ? employeeOptional.get() : null;
    }

    @Override
    public boolean deleteById(String employeeId) {
        employeeRepository.deleteById(employeeId);
        return true;
    }

    @Override
    public boolean isEmployeeExist(String employeeId) {
        return employeeRepository.existsById(employeeId);
    }

    @Override
    public List<Employee> firstName(String firstName) {
        return employeeCustomRepository.doSomething(firstName);
    }

    @Override
    public List<CountByDepartment> countByDept() {
        return employeeCustomRepository.countByDepartment();
    }


//    @Override
//    public Employee update(EmployeeDto employeeDto, String employeeId) {
//        Optional<Employee> employeeOptional = employeeRepository.findById(employeeId);
//        Employee employee = employeeOptional.orElse(null);
//        if (Objects.nonNull(employee)) {
//            BeanUtils.copyProperties(employeeDto, employee);
//            employee.setDob(new Date(employeeDto.getDob()));
//            employee.setDoj(new Date(employeeDto.getDoj()));
//            employee.setEmployeeId(employee.getEmployeeId());
//
//            return employee;
//
//        }
//        else
//            return null;
//    }



}
