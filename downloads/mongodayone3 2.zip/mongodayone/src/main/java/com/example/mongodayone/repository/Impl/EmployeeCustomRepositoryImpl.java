package com.example.mongodayone.repository.Impl;

import com.example.mongodayone.dto.CountByDepartment;
import com.example.mongodayone.entity.Employee;
import com.example.mongodayone.repository.EmployeeCustomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.GroupOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.List;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.group;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.project;

@Component
public class EmployeeCustomRepositoryImpl implements EmployeeCustomRepository {

    @Autowired
    MongoTemplate mongoTemplate;

    @Override
    public List<Employee> doSomething(String firstName) {
        Query query= new Query();
        Criteria criteria = new Criteria();
        criteria.andOperator(Criteria.where("firstName").is(firstName));
        query.addCriteria(criteria);
        List<Employee> employees= mongoTemplate.find(query,Employee.class);
        return employees;
    }

    @Override
    public List<CountByDepartment> countByDepartment() {
        GroupOperation groupByDepartmentandCount = group("dept")
                .count().as("count");
        ProjectionOperation projectionOperation = project().and("_id").as("department")
                .and("count").as("department_count");

        Aggregation aggregation = newAggregation(groupByDepartmentandCount,projectionOperation);

        return mongoTemplate.aggregate(aggregation,Employee.class,CountByDepartment.class).getMappedResults();

    }


}
