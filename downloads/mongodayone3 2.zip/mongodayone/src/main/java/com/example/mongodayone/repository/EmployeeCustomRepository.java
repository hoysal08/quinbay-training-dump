package com.example.mongodayone.repository;


import com.example.mongodayone.dto.CountByDepartment;
import com.example.mongodayone.entity.Employee;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.Update;
import org.springframework.stereotype.Repository;

import java.util.List;


public interface EmployeeCustomRepository{
        List<Employee> doSomething(String firstName);

        List<CountByDepartment> countByDepartment();
}
