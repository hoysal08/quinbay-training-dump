package com.example.mongodayone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongodayoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongodayoneApplication.class, args);
	}

}
