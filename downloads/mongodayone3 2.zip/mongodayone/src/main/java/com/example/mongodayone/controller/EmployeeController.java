package com.example.mongodayone.controller;

import com.example.mongodayone.dto.CountByDepartment;
import com.example.mongodayone.dto.EmployeeDto;
import com.example.mongodayone.dto.EmployeeResponseDto;
import com.example.mongodayone.entity.Employee;
import com.example.mongodayone.servics.EmployeeService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.Update;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @PostMapping("/add")
    public boolean addEmployee(@RequestBody EmployeeDto employeeDto){

        return employeeService.addEmployee(employeeDto);

    }


    @GetMapping
    public List<EmployeeResponseDto> getAllEmployee() {
        List<Employee> data = employeeService.getAll();
        List<EmployeeResponseDto> responseDtos = new ArrayList<>();
        for(Employee employee:data){
            EmployeeResponseDto employeeDto = new EmployeeResponseDto();
            BeanUtils.copyProperties(employee,employeeDto);

            employeeDto.setDob(employee.getDob().getTime());
            employeeDto.setDoj(employee.getDoj().getTime());
            responseDtos.add(employeeDto);

        }
        return responseDtos;
    }

    @GetMapping("/{id}")
    public EmployeeResponseDto getEmployeeById(@PathVariable String id){
        Employee employee = employeeService.get(id);
        EmployeeResponseDto employeeDto = new EmployeeResponseDto();
        BeanUtils.copyProperties(employee,employeeDto);
        employeeDto.setDob(employee.getDob().getTime());
        employeeDto.setDoj(employee.getDoj().getTime());
        return employeeDto;

    }

    @DeleteMapping
    public boolean deleteAll(){
        return employeeService.clearAll();
    }

    @GetMapping("name/{firstName}")
    public List<EmployeeResponseDto> getbyFirstName(@PathVariable String firstName){
        List<Employee> data = employeeService.firstName(firstName);
        List<EmployeeResponseDto> responseDtos = new ArrayList<>();
        for(Employee employee:data){
            EmployeeResponseDto employeeDto = new EmployeeResponseDto();
            BeanUtils.copyProperties(employee,employeeDto);

            employeeDto.setDob(employee.getDob().getTime());
            employeeDto.setDoj(employee.getDoj().getTime());
            responseDtos.add(employeeDto);

        }
        return responseDtos;
    }

    @GetMapping("/countByDept")
    public List<CountByDepartment> getCount(){
        return employeeService.countByDept();
    }


//    @Update("/{id}")
//    public EmployeeDto updateById(@RequestBody EmployeeDto employeeDto,@PathVariable String employeeId){
//        return employeeService.update(employeeDto,employeeId);
//    }
}
