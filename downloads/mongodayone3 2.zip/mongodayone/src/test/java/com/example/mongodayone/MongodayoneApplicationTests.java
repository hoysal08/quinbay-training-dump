package com.example.mongodayone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongodayoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
