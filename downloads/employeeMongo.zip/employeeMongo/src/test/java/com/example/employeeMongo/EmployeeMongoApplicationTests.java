package com.example.employeeMongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeMongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
