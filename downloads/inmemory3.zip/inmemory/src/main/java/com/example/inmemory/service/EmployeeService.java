package com.example.inmemory.service;

import com.example.inmemory.dto.EmployeeDto;
import com.example.inmemory.dto.EmployeeResponseDto;
import com.example.inmemory.entity.Employee;

import java.util.List;

public interface EmployeeService {

    boolean addEmployee(EmployeeDto employeeDto);

    List<Employee> getAll();

    boolean deleteEmployeeById(String EmployeeId);


}
