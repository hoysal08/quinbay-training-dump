package com.example.inmemory.repository.impl;

import com.example.inmemory.entity.Employee;
import com.example.inmemory.repository.EmployeeRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class EmployeeRespositoryImpl implements EmployeeRepository {

    private Map<String , Employee> data = null;

    @PostConstruct
    void init(){
        data = new HashMap<>();
    }

    @Override
    public Employee addEmployee(Employee employee) {
         data.put(employee.getEmployeeId(),employee);
         return employee;
    }

    @Override
    public Employee getEmployee(String employeeId) {
        return data.get(employeeId);
    }

    @Override
    public List<Employee> getAllEmployee() {
        return new ArrayList<>(data.values());
    }

    @Override
    public boolean deleteEmployeeById(String employeeId) {
        Employee deleteObj = data.remove(employeeId);
        return deleteObj != null;
    }
    @Override
    public boolean existsEmployeeId(String employeeId) {
        return data.containsKey(employeeId);
    }

    @Override
    public void clearAll() {
        data.clear();
    }
}
