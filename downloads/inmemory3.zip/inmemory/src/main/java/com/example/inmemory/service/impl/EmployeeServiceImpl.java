package com.example.inmemory.service.impl;

import com.example.inmemory.dto.EmployeeDto;
import com.example.inmemory.dto.EmployeeResponseDto;
import com.example.inmemory.entity.Employee;
import com.example.inmemory.repository.EmployeeRepository;
import com.example.inmemory.service.EmployeeService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;
    private EmployeeService employeeService;

    @Override
    public boolean addEmployee(EmployeeDto employeeDto) {

        Employee employee = new Employee();
        BeanUtils.copyProperties(employeeDto,employee);
        employee.setDob(new Date(employeeDto.getDob()));
        employee.setDoj(new Date(employeeDto.getDoj()));
        employee.setEmployeeId(UUID.randomUUID().toString());
        Employee savedEmployee = employeeRepository.addEmployee(employee);
        return Objects.nonNull(savedEmployee);
    }

    @Override
    public List<Employee> getAll() {
        List<Employee> data = employeeRepository.getAllEmployee();
        return data;
    }

    @Override
    public boolean deleteEmployeeById(String EmployeeId) {
        return employeeRepository.deleteEmployeeById(EmployeeId);
    }


}
