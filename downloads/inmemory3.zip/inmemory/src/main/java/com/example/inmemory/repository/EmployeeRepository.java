package com.example.inmemory.repository;

import com.example.inmemory.entity.Employee;

import java.util.List;

public interface EmployeeRepository {
    Employee addEmployee(Employee employee);
    Employee getEmployee(String employeeId);

    List<Employee> getAllEmployee();

    boolean deleteEmployeeById(String employeeId);

    boolean existsEmployeeId(String employeeId);

    void clearAll();
}
