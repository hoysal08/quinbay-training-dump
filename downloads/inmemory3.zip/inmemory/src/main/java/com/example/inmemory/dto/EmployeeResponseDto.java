package com.example.inmemory.dto;

import lombok.Data;

@Data
public class EmployeeResponseDto {
    private String employeeId;
    private String firstName;
    private String lastName;
    private long dob;
    private long doj;
}
