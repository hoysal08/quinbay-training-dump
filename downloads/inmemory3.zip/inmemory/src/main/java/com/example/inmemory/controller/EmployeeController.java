package com.example.inmemory.controller;

import com.example.inmemory.dto.EmployeeDto;
import com.example.inmemory.dto.EmployeeResponseDto;
import com.example.inmemory.entity.Employee;
import com.example.inmemory.service.EmployeeService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @PostMapping
    public boolean addEmployee(@RequestBody EmployeeDto employeeDto){

        return employeeService.addEmployee(employeeDto);

    }

    @GetMapping
    public List<EmployeeResponseDto> getAllEmployee() {
        List<Employee> data = employeeService.getAll();
        List<EmployeeResponseDto> responseDtos = new ArrayList<>();
        for(Employee employee:data){
            EmployeeResponseDto employeeDto = new EmployeeResponseDto();
            BeanUtils.copyProperties(employee,employeeDto);

            employeeDto.setDob(employee.getDob().getTime());
            employeeDto.setDoj(employee.getDoj().getTime());
            responseDtos.add(employeeDto);

        }
        return responseDtos;
    }


    @DeleteMapping("delete/{id}")
    public boolean deleteEmployeeById(@PathVariable String id){
        return employeeService.deleteEmployeeById(id);

    }

//    @GetMapping("/id/{employeeId}"){

//    }
}
